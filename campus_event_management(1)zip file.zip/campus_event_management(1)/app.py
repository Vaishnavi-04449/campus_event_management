from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import os

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///campus_events.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Models
class College(db.Model):
    __tablename__ = 'colleges'
    college_id = db.Column(db.String(10), primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    location = db.Column(db.String(100))
    contact_email = db.Column(db.String(100))
    events = db.relationship('Event', backref='college', lazy=True)
    students = db.relationship('Student', backref='college', lazy=True)

class Event(db.Model):
    __tablename__ = 'events'
    event_id = db.Column(db.String(20), primary_key=True)
    college_id = db.Column(db.String(10), db.ForeignKey('colleges.college_id'), nullable=False)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    event_type = db.Column(db.String(50), nullable=False)
    event_date = db.Column(db.DateTime, nullable=False)
    capacity = db.Column(db.Integer, default=100)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), default='active')
    registrations = db.relationship('Registration', backref='event', lazy=True)

class Student(db.Model):
    __tablename__ = 'students'
    student_id = db.Column(db.String(20), primary_key=True)
    college_id = db.Column(db.String(10), db.ForeignKey('colleges.college_id'), nullable=False)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    phone = db.Column(db.String(15))
    year = db.Column(db.Integer)
    registrations = db.relationship('Registration', backref='student', lazy=True)

class Registration(db.Model):
    __tablename__ = 'registrations'
    registration_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    student_id = db.Column(db.String(20), db.ForeignKey('students.student_id'), nullable=False)
    event_id = db.Column(db.String(20), db.ForeignKey('events.event_id'), nullable=False)
    registration_date = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), default='registered')
    attendance = db.relationship('Attendance', backref='registration', uselist=False)
    feedback = db.relationship('Feedback', backref='registration', uselist=False)
    __table_args__ = (db.UniqueConstraint('student_id', 'event_id', name='unique_registration'),)

class Attendance(db.Model):
    __tablename__ = 'attendance'
    attendance_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    registration_id = db.Column(db.Integer, db.ForeignKey('registrations.registration_id'), nullable=False)
    check_in_time = db.Column(db.DateTime, default=datetime.utcnow)
    status = db.Column(db.String(20), default='present')

class Feedback(db.Model):
    __tablename__ = 'feedback'
    feedback_id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    registration_id = db.Column(db.Integer, db.ForeignKey('registrations.registration_id'), nullable=False)
    rating = db.Column(db.Integer, nullable=False)
    comments = db.Column(db.Text)
    submitted_at = db.Column(db.DateTime, default=datetime.utcnow)

# API Routes
@app.route('/api/colleges', methods=['GET', 'POST'])
def handle_colleges():
    if request.method == 'GET':
        colleges = College.query.all()
        return jsonify([{
            'college_id': c.college_id,
            'name': c.name,
            'location': c.location,
            'contact_email': c.contact_email
        } for c in colleges])
    
    elif request.method == 'POST':
        data = request.json
        college = College(
            college_id=data['college_id'],
            name=data['name'],
            location=data.get('location', ''),
            contact_email=data.get('contact_email', '')
        )
        db.session.add(college)
        db.session.commit()
        return jsonify({'message': 'College created successfully'}), 201

@app.route('/api/students', methods=['POST'])
def create_student():
    data = request.json
    student = Student(
        student_id=data['student_id'],
        college_id=data['college_id'],
        name=data['name'],
        email=data['email'],
        phone=data.get('phone', ''),
        year=data.get('year', 1)
    )
    db.session.add(student)
    db.session.commit()
    return jsonify({'message': 'Student created successfully'}), 201

@app.route('/api/events', methods=['GET', 'POST'])
def handle_events():
    if request.method == 'GET':
        college_id = request.args.get('college_id')
        event_type = request.args.get('event_type')
        
        query = Event.query
        if college_id:
            query = query.filter_by(college_id=college_id)
        if event_type:
            query = query.filter_by(event_type=event_type)
            
        events = query.all()
        return jsonify([{
            'event_id': e.event_id,
            'title': e.title,
            'description': e.description,
            'event_type': e.event_type,
            'event_date': e.event_date.isoformat(),
            'capacity': e.capacity,
            'college_name': e.college.name
        } for e in events])
    
    elif request.method == 'POST':
        data = request.json
        event_id = f"{data['college_id']}_{data['title'][:10].replace(' ', '')}_{len(Event.query.all()) + 1}"
        
        event = Event(
            event_id=event_id,
            college_id=data['college_id'],
            title=data['title'],
            description=data.get('description', ''),
            event_type=data['event_type'],
            event_date=datetime.fromisoformat(data['event_date']),
            capacity=data.get('capacity', 100)
        )
        db.session.add(event)
        db.session.commit()
        return jsonify({'message': 'Event created successfully', 'event_id': event_id}), 201

@app.route('/api/registrations', methods=['POST'])
def register_student():
    data = request.json
    
    existing = Registration.query.filter_by(
        student_id=data['student_id'],
        event_id=data['event_id']
    ).first()
    
    if existing:
        return jsonify({'error': 'Student already registered for this event'}), 400
    
    event = Event.query.get(data['event_id'])
    current_registrations = Registration.query.filter_by(event_id=data['event_id']).count()
    
    if current_registrations >= event.capacity:
        return jsonify({'error': 'Event is at full capacity'}), 400
    
    registration = Registration(
        student_id=data['student_id'],
        event_id=data['event_id']
    )
    
    db.session.add(registration)
    db.session.commit()
    
    return jsonify({'message': 'Registration successful', 'registration_id': registration.registration_id}), 201

@app.route('/api/attendance', methods=['POST'])
def mark_attendance():
    data = request.json
    
    registration = Registration.query.get(data['registration_id'])
    if not registration:
        return jsonify({'error': 'Registration not found'}), 404
    
    existing_attendance = Attendance.query.filter_by(registration_id=data['registration_id']).first()
    if existing_attendance:
        return jsonify({'error': 'Attendance already marked'}), 400
    
    attendance = Attendance(
        registration_id=data['registration_id'],
        status='present'
    )
    
    db.session.add(attendance)
    db.session.commit()
    
    return jsonify({'message': 'Attendance marked successfully'}), 201

@app.route('/api/feedback', methods=['POST'])
def submit_feedback():
    data = request.json
    
    if data['rating'] < 1 or data['rating'] > 5:
        return jsonify({'error': 'Rating must be between 1 and 5'}), 400
    
    feedback = Feedback(
        registration_id=data['registration_id'],
        rating=data['rating'],
        comments=data.get('comments', '')
    )
    
    db.session.add(feedback)
    db.session.commit()
    
    return jsonify({'message': 'Feedback submitted successfully'}), 201

@app.route('/api/reports/event-popularity', methods=['GET'])
def event_popularity_report():
    results = db.session.query(
        Event.event_id,
        Event.title,
        Event.event_type,
        College.name.label('college_name'),
        db.func.count(Registration.registration_id).label('total_registrations')
    ).join(Registration, Event.event_id == Registration.event_id, isouter=True)\
     .join(College).group_by(Event.event_id)\
     .order_by(db.desc('total_registrations')).all()
    
    return jsonify([{
        'event_id': r.event_id,
        'title': r.title,
        'event_type': r.event_type,
        'college_name': r.college_name,
        'total_registrations': r.total_registrations or 0
    } for r in results])

@app.route('/api/reports/student-participation', methods=['GET'])
def student_participation_report():
    results = db.session.query(
        Student.student_id,
        Student.name,
        College.name.label('college_name'),
        db.func.count(Attendance.attendance_id).label('events_attended')
    ).join(Registration, Student.student_id == Registration.student_id, isouter=True)\
     .join(Attendance, Registration.registration_id == Attendance.registration_id, isouter=True)\
     .join(College).group_by(Student.student_id)\
     .order_by(db.desc('events_attended')).all()
    
    return jsonify([{
        'student_id': r.student_id,
        'name': r.name,
        'college_name': r.college_name,
        'events_attended': r.events_attended or 0
    } for r in results])

@app.route('/api/reports/top-active-students', methods=['GET'])
def top_active_students():
    results = db.session.query(
        Student.student_id,
        Student.name,
        College.name.label('college_name'),
        db.func.count(Attendance.attendance_id).label('events_attended')
    ).join(Registration)\
     .join(Attendance)\
     .join(College)\
     .group_by(Student.student_id)\
     .order_by(db.desc('events_attended'))\
     .limit(3).all()
    
    return jsonify([{
        'student_id': r.student_id,
        'name': r.name,
        'college_name': r.college_name,
        'events_attended': r.events_attended
    } for r in results])

@app.route('/api/sample-data', methods=['POST'])
def insert_sample_data():
    colleges_data = [
        {'college_id': 'ABC001', 'name': 'ABC Engineering College', 'location': 'Mumbai'},
        {'college_id': 'XYZ002', 'name': 'XYZ Institute of Technology', 'location': 'Pune'},
        {'college_id': 'DEF003', 'name': 'DEF University', 'location': 'Bangalore'}
    ]
    
    for college_data in colleges_data:
        if not College.query.get(college_data['college_id']):
            college = College(**college_data)
            db.session.add(college)
    
    students_data = [
        {'student_id': 'ABC001_S001', 'college_id': 'ABC001', 'name': 'John Doe', 'email': 'john@abc.edu', 'year': 2},
        {'student_id': 'ABC001_S002', 'college_id': 'ABC001', 'name': 'Jane Smith', 'email': 'jane@abc.edu', 'year': 3},
        {'student_id': 'XYZ002_S001', 'college_id': 'XYZ002', 'name': 'Bob Wilson', 'email': 'bob@xyz.edu', 'year': 1},
        {'student_id': 'DEF003_S001', 'college_id': 'DEF003', 'name': 'Charlie Davis', 'email': 'charlie@def.edu', 'year': 2},
    ]
    
    for student_data in students_data:
        if not Student.query.get(student_data['student_id']):
            student = Student(**student_data)
            db.session.add(student)
    
    events_data = [
        {'college_id': 'ABC001', 'title': 'Tech Hackathon 2025', 'event_type': 'Hackathon', 'event_date': '2025-09-15T10:00:00', 'capacity': 50},
        {'college_id': 'ABC001', 'title': 'AI Workshop', 'event_type': 'Workshop', 'event_date': '2025-09-20T14:00:00', 'capacity': 30},
        {'college_id': 'XYZ002', 'title': 'Cultural Fest', 'event_type': 'Fest', 'event_date': '2025-09-25T09:00:00', 'capacity': 200},
    ]
    
    for i, event_data in enumerate(events_data):
        event_id = f"{event_data['college_id']}_{event_data['title'][:10].replace(' ', '')}_{i+1}"
        if not Event.query.get(event_id):
            event = Event(
                event_id=event_id,
                college_id=event_data['college_id'],
                title=event_data['title'],
                event_type=event_data['event_type'],
                event_date=datetime.fromisoformat(event_data['event_date']),
                capacity=event_data['capacity']
            )
            db.session.add(event)
    
    db.session.commit()
    return jsonify({'message': 'Sample data inserted successfully'}), 201

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True, port=5000)