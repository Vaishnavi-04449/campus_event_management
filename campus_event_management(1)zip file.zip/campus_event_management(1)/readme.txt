# Campus Event Management Platform

## My Understanding of the Project

I built this system to solve the problem of managing events across multiple colleges. The main challenge was creating a system that can handle multiple colleges while keeping their data separate but still allowing cross-college participation.

## What I Built

This is a web API that allows:
- Colleges to create and manage events
- Students to register for events
- Tracking attendance and collecting feedback
- Generating reports for administrators

## Technology Choices

I chose Python Flask because it's simple and fast for prototyping. SQLite works well for this prototype size. The database design uses foreign keys to link everything together properly.

## How to Run

1. Install Python 3.9+
2. Run: pip install -r requirements.txt
3. Run: python app.py
4. Test: python test_api.py

## Key Features

- Multi-college support with data separation
- Event registration with capacity limits
- Attendance tracking separate from registration
- Feedback collection with 1-5 ratings
- Multiple report types for analytics

## What I Learned

This project taught me about designing multi-tenant systems and handling complex database relationships. The biggest challenge was ensuring data integrity across all the tables.